# 算法方案文档 LaTeX 模板

这是一个专为中文算法方案文档设计的 LaTeX 模板，包含封面、方法、实验、结论和参考文献等完整结构。

## 文件结构

```
├── algorithm_paper_template.tex  # 主LaTeX文档
├── references.bib               # 参考文献数据库
├── Makefile                    # 编译脚本
└── README_latex.md             # 使用说明
```

## 环境要求

### 必需软件
- **LaTeX发行版**: 推荐使用 MacTeX (macOS) 或 TeX Live (Linux/Windows)
- **中文支持**: 确保安装了 `ctex` 宏包
- **编译器**: XeLaTeX（推荐）或 pdfLaTeX

### 安装 LaTeX (macOS)
```bash
# 使用 Homebrew 安装 MacTeX
brew install --cask mactex

# 或者下载完整版 MacTeX
# 访问: https://www.tug.org/mactex/
```

### 安装 LaTeX (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install texlive-full
sudo apt-get install texlive-lang-chinese
```

## 快速开始

### 方法一：使用 Makefile（推荐）

```bash
# 编译生成 PDF 和 ZIP 压缩包
make

# 或者分步执行
make pdf    # 仅编译 PDF
make zip    # 编译 PDF 并创建 ZIP 压缩包
```

### 方法二：手动编译

```bash
# 完整编译流程（包含参考文献）
xelatex algorithm_paper_template.tex
bibtex algorithm_paper_template
xelatex algorithm_paper_template.tex
xelatex algorithm_paper_template.tex

# 创建 ZIP 压缩包
zip -r algorithm_paper_template.zip algorithm_paper_template.tex references.bib algorithm_paper_template.pdf
```

### 方法三：快速编译（无参考文献）

```bash
make quick
# 或者
xelatex algorithm_paper_template.tex
```

## 模板结构说明

### 1. 封面页
- 文档标题
- 个人信息（姓名、学号、专业、学院、指导教师）
- 日期

### 2. 主要章节
- **方法**: 问题描述、算法设计、复杂度分析
- **实验**: 实验环境、数据集、实验设计、结果分析
- **结论**: 主要贡献、局限性、未来工作
- **参考文献**: 支持 BibTeX 和手动添加两种方式

### 3. 特色功能
- 中文支持（使用 ctex 宏包）
- 算法伪代码环境
- 代码高亮显示
- 表格和图片支持
- 超链接和交叉引用
- 自动目录生成

## 自定义指南

### 修改个人信息
编辑 `algorithm_paper_template.tex` 文件中的封面部分：

```latex
\begin{tabular}{ll}
    \textbf{姓名：} & [在此填写姓名] \\
    \textbf{学号：} & [在此填写学号] \\
    \textbf{专业：} & [在此填写专业] \\
    \textbf{学院：} & [在此填写学院] \\
    \textbf{指导教师：} & [在此填写指导教师] \\
\end{tabular}
```

### 添加参考文献

#### 方法一：使用 BibTeX（推荐）
1. 在 `references.bib` 文件中添加文献条目
2. 在正文中使用 `\cite{引用键}` 引用

示例：
```bibtex
@article{zhang2023algorithm,
    title={新型算法研究},
    author={张三 and 李四},
    journal={计算机学报},
    year={2023}
}
```

#### 方法二：手动添加
在文档末尾的 `thebibliography` 环境中添加：
```latex
\bibitem{ref1} 作者. 标题[J]. 期刊, 年份.
```

### 插入图片
```latex
\begin{figure}[H]
\centering
\includegraphics[width=0.8\textwidth]{图片文件名}
\caption{图片标题}
\label{fig:标签}
\end{figure}
```

### 插入表格
```latex
\begin{table}[H]
\centering
\caption{表格标题}
\begin{tabular}{@{}lcc@{}}
\toprule
列1 & 列2 & 列3 \\
\midrule
数据1 & 数据2 & 数据3 \\
\bottomrule
\end{tabular}
\end{table}
```

### 插入算法
```latex
\begin{algorithm}[H]
\caption{算法名称}
\begin{algorithmic}[1]
\REQUIRE 输入
\ENSURE 输出
\STATE 步骤1
\IF{条件}
    \STATE 步骤2
\ENDIF
\RETURN 结果
\end{algorithmic}
\end{algorithm}
```

## 常用命令

```bash
# 查看可用命令
make help

# 清理临时文件
make clean

# 清理所有生成文件
make clean-all
```

## 故障排除

### 编译错误
1. **中文显示问题**: 确保使用 XeLaTeX 编译器
2. **宏包缺失**: 安装完整的 LaTeX 发行版
3. **参考文献不显示**: 确保运行了 `bibtex` 命令

### 常见问题
- **Q**: 为什么需要编译多次？
  **A**: LaTeX 需要多次编译来正确处理交叉引用、目录和参考文献

- **Q**: 如何更改字体？
  **A**: 在文档导言区添加字体设置命令

- **Q**: 如何调整页面布局？
  **A**: 修改 `\geometry{}` 命令中的参数

## 输出文件

编译成功后将生成：
- `algorithm_paper_template.pdf` - 最终的PDF文档
- `algorithm_paper_template.zip` - 包含源码和PDF的压缩包

## 技术支持

如果遇到问题，请检查：
1. LaTeX 发行版是否正确安装
2. 所有必需的宏包是否可用
3. 编译命令是否正确执行

---

**注意**: 此模板专为中文学术文档设计，如需英文版本，请相应调整语言设置和宏包配置。